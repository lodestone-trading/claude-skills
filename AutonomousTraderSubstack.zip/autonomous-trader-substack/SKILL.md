---
name: autonomous-trader-substack
description: Content strategy and writing assistance for The Autonomous Trader Substack publication. Use when evaluating post ideas, editing drafts, generating content, analyzing audience segments, scheduling posts for biweekly cadence, or improving writing clarity for technical trading content. Triggers include requests to evaluate themes, score post ideas, edit Substack drafts, suggest topics, analyze reader segments, plan content calendars, or improve writing flow and clarity.
---

# The Autonomous Trader Substack Skill

Strategic guidance for creating, evaluating, and scheduling content for The Autonomous Trader publication—a biweekly Substack focused on solo systematic trading, autonomous finance systems, and ML infrastructure.

## Core Brand Positioning

**Central Thesis:** "One person plus AI can compete with institutional teams through superior infrastructure design"

**Target Reader:** System builders, quant practitioners, solo operators, and ML engineers who want production depth—not academics seeking theory or retail traders seeking tactics.

**Unique Value:** Technical credibility + operational honesty. You share production ML lessons institutions won't write about and bridge theory to implementation that academics ignore.

**Voice:** Direct, analytical, minimal pleasantries. Technical depth without condescension. Honest about failures. Focus on infrastructure as competitive moat.

## Content Evaluation Framework

### The 7 Theme Categories

Every post must clearly fit into one primary theme. Use this rubric to evaluate or generate content:

#### 1. Autonomous Systems Architecture (25% of posts)

**What it covers:**
- Technical infrastructure for trading at scale
- Production ML implementations and design decisions  
- System architecture choices (PyTorch, MLflow, monitoring stack)
- Multi-task learning across portfolio
- Why specific tools/approaches over alternatives

**Good post indicators:**
- Deep technical implementation details
- Real production trade-offs and decisions
- Architecture diagrams or system design
- Explains "why this way" not just "what"
- Teaches patterns others can apply

**Bad post indicators:**
- Surface-level tool descriptions
- Generic "how to use X" tutorials
- No production context or constraints
- Reads like vendor marketing
- Missing the "autonomous" angle

**Example titles:**
- "Multi-Task Learning Across 1,350 Stocks: Architecture Decisions"
- "Why I Self-Host Trading Infrastructure vs. Cloud"
- "Production Monitoring Stack: Grafana + Loki + Prometheus"
- "Transformer Architectures for Portfolio-Level Decisions"

**Evaluation questions:**
- Does this teach production ML for trading?
- Would an institutional quant learn something?
- Is the technical depth sufficient?
- Does it reinforce the autonomous/infrastructure thesis?

---

#### 2. Solo Operator Realities (20% of posts)

**What it covers:**
- Unit economics of one-person trading operations
- Resource allocation decisions (time, money, attention)
- What scales vs. doesn't with one person
- Trade-offs between building vs. buying vs. ignoring
- Real costs and business fundamentals

**Good post indicators:**
- Specific numbers and economic reality
- Honest discussion of constraints
- Strategic resource allocation decisions
- Proves infrastructure thesis through results
- Actionable for other solo operators

**Bad post indicators:**
- Vague "lifestyle design" fluff
- Aspirational without substance
- Survivorship bias without acknowledging luck
- Reads like motivational content
- Missing concrete examples

**Example titles:**
- "The Real P&L of Solo Systematic Trading: Five Year Economics"
- "Time ROI: Which Infrastructure Investments Actually Compound"
- "Why I Don't Hire: A Five-Year Retrospective"
- "Building vs. Buying: Decision Framework for Solo Operators"

**Evaluation questions:**
- Does this show real operational decisions?
- Are there concrete numbers or examples?
- Is this differentiated from generic entrepreneur content?
- Does it prove the solo+AI thesis?

---

#### 3. Decision-Making & Lessons (15% of posts)

**What it covers:**
- Strategic pivots and the reasoning behind them
- Technical and strategic failures with post-mortems
- Risk management philosophy (technical + psychological)
- Evolution of thinking over five years
- What you'd do differently knowing what you know now

**Good post indicators:**
- Specific failure stories with technical details
- Honest about what went wrong
- Lessons extracted from real experience
- Shows decision-making process
- Avoids "here's what I learned" platitudes

**Bad post indicators:**
- Generic startup lessons
- Success stories without failures
- Vague "trust your gut" advice
- Missing technical specifics
- Reads like LinkedIn inspiration post

**Example titles:**
- "When My Optimal Stopping System Failed Spectacularly"
- "Five Years of Lessons in 5,000 Words"
- "The Risk Model That Broke at 3AM: Post-Mortem"
- "Strategic Pivots: Why I Rebuilt My Execution Layer Twice"

**Evaluation questions:**
- Is there a specific story or decision?
- Does it include technical details?
- Are the lessons non-obvious?
- Would readers remember this failure?

---

#### 4. Applied Quantitative Education (15% of posts)

**What it covers:**
- ML/statistics concepts through production lens
- Reading list annotations and implementation commentary
- Theory-to-practice bridges (academic → production)
- Quantitative methods framed for autonomous systems
- "How to implement X reliably" content

**Good post indicators:**
- Takes academic concept to production reality
- Explains what papers don't cover
- Practical implementation guidance
- Bridges theory and autonomous trading
- Cites sources and provides path to deeper learning

**Bad post indicators:**
- Pure theory with no production angle
- Copy-paste from textbooks
- Generic "intro to X" content
- Missing the autonomous systems framing
- No clear implementation path

**Example titles:**
- "Dimensionality Reduction for Systems That Run Without You"
- "From Sutton & Barto to Production: Optimal Stopping Implementation"
- "Reading List: Building Trading Systems from First Principles"
- "Uncertainty Quantification: How Systems Know What They Don't Know"

**Evaluation questions:**
- Does it bridge theory to implementation?
- Is the autonomous angle clear?
- Would this help someone build real systems?
- Does it cite and build on existing work?

---

#### 5. Career & Skill Development (10% of posts)

**What it covers:**
- PhD → Microsoft Research → Amazon → Trading transition
- How to build expertise autonomously
- Learning strategies that worked (and didn't)
- Skills that transfer between domains
- How to learn without a team or formal training

**Good post indicators:**
- Specific career transition stories
- Transferable learning frameworks
- Honest about what was hard
- Practical advice for similar transitions
- Shows the path, not just the destination

**Bad post indicators:**
- Generic career advice
- Survivorship bias without nuance
- "Follow your passion" platitudes
- Missing domain-specific insights
- Reads like career coach content

**Example titles:**
- "From Deep Learning Researcher to Systematic Trader"
- "How I Learn New Domains Without a Team"
- "Skills That Transfer from ML Research to Trading"
- "Building Expertise in Quantitative Finance: A Five-Year Roadmap"

**Evaluation questions:**
- Is this specific to your transition?
- Are the lessons transferable?
- Does it avoid generic career advice?
- Would someone in a similar position find this useful?

---

#### 6. Market Intelligence Through Systems (10% of posts)

**What it covers:**
- What monitoring 1,350 stocks reveals about markets
- Automated regime detection and market structure
- Observations from systematic perspective
- How autonomous systems surface market insights
- Pattern recognition at scale

**Good post indicators:**
- Data-driven observations
- Unique systematic perspective
- No positions or directional calls
- Focus on methodology over predictions
- Shows what large-scale monitoring reveals

**Bad post indicators:**
- Market predictions or calls
- Generic market commentary
- Reads like financial news
- Missing the systems angle
- No methodological insight

**Example titles:**
- "What 1,350 Stocks Teach About Correlation Regimes"
- "How Automated Systems Detect Market Stress"
- "Regime Detection at Scale: Production Implementation"
- "Cross-Sectional Patterns Only Visible at Portfolio Scale"

**Evaluation questions:**
- Does it show systems-level insights?
- Is methodology discussed?
- Does it avoid market predictions?
- Is the scale/automation angle clear?

---

#### 7. Mental Models & Philosophy (5% of posts)

**What it covers:**
- Decision frameworks beyond trading
- Business wisdom from reading list
- Operational philosophy and principles
- Strategic thinking that applies broadly
- Synthesizing ideas from diverse sources

**Good post indicators:**
- Connects diverse ideas to trading operations
- Shows how mental models apply
- Draws from reading list authentically
- Provides actionable framework
- Not just book summaries

**Bad post indicators:**
- Generic book reviews
- Surface-level philosophy
- Missing application to trading/ops
- Reads like book club notes
- No clear operational takeaway

**Example titles:**
- "Applying 'The Art of War' to Solo Trading Operations"
- "Knight's Risk vs. Uncertainty in Production Systems"
- "Decision Frameworks from Five Years of Reading"
- "Skin in the Game: What Taleb Gets Right About Trading"

**Evaluation questions:**
- Does it synthesize ideas uniquely?
- Is the application to trading clear?
- Would readers gain actionable insight?
- Does it show your thinking, not just summarize?

---

## Content Scoring System

Rate posts on three dimensions (1-10 scale):

### 1. Strategic Fit
- **10:** Perfect embodiment of brand thesis; couldn't be written by anyone else
- **7-9:** Strong fit; reinforces positioning; shows unique expertise
- **4-6:** Acceptable but generic; many could write similar content
- **1-3:** Off-brand or dilutes positioning

**Red flags:** Generic startup advice, lifestyle content, get-rich-quick framing, purely aspirational messaging

### 2. Technical Credibility
- **10:** Deep production insights institutions won't share; teaches patterns
- **7-9:** Solid technical depth; bridges theory to practice well
- **4-6:** Surface-level; missing implementation details
- **1-3:** Generic or incorrect technical content

**Red flags:** No production context, reads like tutorial, missing "why" decisions, purely theoretical

### 3. Reader Value
- **10:** Actionable insights they can't find elsewhere; memorable lessons
- **7-9:** Useful; provides clear takeaways; worth their time
- **4-6:** Interesting but not actionable; forgettable
- **1-3:** Obvious, generic, or time-wasting

**Red flags:** Obvious advice, no specific examples, missing concrete lessons, pure theory

### Overall Rating
- **27-30:** Flagship post; publish immediately
- **21-26:** Strong post; minor refinements
- **15-20:** Needs work; clarify theme or add depth
- **Below 15:** Reconsider or major revision

---

## Audience Segment Analysis

### Primary Segments (Priority Order)

#### 1. Systematic Traders & Quants (40% target)

**Profile:**
- Building or running their own trading systems
- Technical background in CS/ML/stats
- Want production depth, not theory
- Frustrated with sanitized institutional content

**What they want:**
- Real infrastructure decisions with trade-offs
- Production ML implementations
- Honest failure stories
- Proof autonomous trading works

**Content priorities:**
- Autonomous Systems Architecture (high)
- Solo Operator Realities (high)
- Applied Quantitative Education (medium)
- Decision-Making & Lessons (medium)

**Engagement signals:**
- Asks technical implementation questions
- Shares posts to quant/ML communities
- Comments with their own production experiences
- Subscribes to deep technical series

---

#### 2. ML Engineers Interested in Trading (30% target)

**Profile:**
- Strong ML background, less finance experience
- Curious about applying skills to trading
- Want to understand if solo trading viable
- Interested in domain transfer

**What they want:**
- How ML skills transfer to trading
- Real economics of solo trading
- Infrastructure patterns from other domains
- Career transition insights

**Content priorities:**
- Career & Skill Development (high)
- Autonomous Systems Architecture (high)
- Applied Quantitative Education (medium)
- Solo Operator Realities (medium)

**Engagement signals:**
- Questions about transitioning to trading
- Compares trading to other ML domains
- Asks about specific tools/frameworks
- Interested in reading lists

---

#### 3. Solo Tech Operators (20% target)

**Profile:**
- Running one-person software/data businesses
- Not necessarily in finance
- Interested in leverage through automation
- Want to learn operational patterns

**What they want:**
- Solo operator economics and decisions
- Infrastructure as competitive advantage
- How to scale without hiring
- Business fundamentals

**Content priorities:**
- Solo Operator Realities (high)
- Autonomous Systems Architecture (medium)
- Decision-Making & Lessons (medium)
- Career & Skill Development (low)

**Engagement signals:**
- Applies lessons to their domain
- Questions about resource allocation
- Interested in build vs. buy decisions
- Shares solo operator insights

---

#### 4. Finance Professionals Exploring Automation (10% target)

**Profile:**
- Traditional finance background
- Curious about systematic approaches
- Less technical, more strategic interest
- Want to understand landscape

**What they want:**
- What systematic trading actually is
- How solo operators compete
- Market intelligence and observations
- Less code, more concepts

**Content priorities:**
- Market Intelligence Through Systems (high)
- Solo Operator Realities (medium)
- Decision-Making & Lessons (medium)
- Mental Models & Philosophy (medium)

**Engagement signals:**
- Questions about market structure
- Interested in competitive dynamics
- Focuses on strategy over implementation
- Asks about institutional vs. solo

---

### Audience Development Strategy

**Attract right readers:**
- Technical depth filters for serious builders
- Production focus filters for practitioners
- Honest failures filter for experienced operators
- Infrastructure thesis filters for strategic thinkers

**Repel wrong readers:**
- No get-rich-quick promises → repels retail gamblers
- No lifestyle fluff → repels aspirational crowd
- High technical bar → repels casual browsers
- Honest about difficulty → repels looking-for-easy-path

**Growth tactics:**
- Cross-post to Hacker News (architecture posts)
- Share to r/algotrading (but frame appropriately)
- Twitter threads on production lessons
- Guest posts on technical infrastructure
- LinkedIn for career transition stories

---

## Publishing Schedule Management

### Biweekly Cadence (24 posts/year)

**Standard pattern:**
- 2 posts per month
- Typically: 1st and 3rd weeks of month
- Alternating technical/human themes
- Build multi-post series across quarters

**Annual content mix targets:**
- Autonomous Systems Architecture: 6 posts
- Solo Operator Realities: 5 posts
- Decision-Making & Lessons: 4 posts
- Applied Quantitative Education: 4 posts
- Career & Skill Development: 2 posts
- Market Intelligence: 2 posts
- Mental Models: 1 post

### Quarterly Planning Framework

**Q1 (Jan-Mar): Foundation Setting**
- Establish technical credibility early
- Mix architecture + solo operator economics
- 1-2 flagship technical posts
- Reading list or career story

**Q2 (Apr-Jun): Deep Dives**
- Multi-part series (2-3 posts)
- Balance technical with lessons learned
- Applied education content
- Market intelligence post

**Q3 (Jul-Sep): Breadth & Variety**
- Rotate through more categories
- Lighter content (summer reading)
- Career/skills content
- Mental models post

**Q4 (Oct-Dec): Strategic & Reflective**
- Year-in-review themes
- Decision-making retrospectives
- Forward-looking architecture
- Reading list updates

### Series Structure Patterns

**Multi-post series (2-4 posts):**
- Post 1: Problem framing + high-level approach
- Post 2: Implementation details + production reality
- Post 3: Lessons learned + what would you change
- Post 4 (optional): Extended case study or deep dive

**Intersperse series with standalone posts** to maintain variety.

**Example Q1 series:**
- Week 1: "Multi-Task Learning: The Portfolio-Scale Problem" (Architecture)
- Week 3: "Solo Operator Economics: Real P&L Over Five Years" (Solo Operator)
- Week 5: "Multi-Task Learning: Production Implementation" (Architecture pt. 2)
- Week 7: "Why I Don't Hire: Five-Year Retrospective" (Decision-Making)

### Content Calendar Template

**For each post, specify:**

1. **Publishing date** (1st or 3rd week of month)
2. **Primary theme** (which of the 7 categories)
3. **Working title** (specific and clear)
4. **Target audience segment** (which 1-2 segments)
5. **Length target** (1500-3500 words)
6. **Series connection** (standalone or part X of Y)
7. **Key takeaway** (one sentence - what should readers remember?)

**Example entry:**
- Date: Week 1, January
- Theme: Autonomous Systems Architecture (25%)
- Title: "The Technical Stack Behind 1,350-Stock Systematic Trading"
- Audience: Systematic Traders & ML Engineers
- Length: 3000 words
- Series: Standalone (foundation post)
- Takeaway: "Infrastructure choices compound over time—here's what I'd build again vs. change"

---

## Writing Clarity Improvements

### Voice & Style Guidelines

**Your natural voice:**
- Direct and analytical
- Minimal pleasantries or filler
- Technical without being condescending
- Honest about failures and uncertainty
- Bullet points over long paragraphs

**Maintain:**
- First-person ("I built", "My system", "We")
- Active voice dominance
- Concrete examples over abstractions
- Specific numbers when possible
- Technical precision

**Avoid:**
- Generic startup platitudes
- Motivational language
- Excessive hedging or apologizing
- Marketing-speak or hype
- Unnecessary politeness

### Structural Patterns

**Opening (first 2-3 paragraphs):**
- State the problem or question clearly
- Why this matters (brief context)
- What you'll cover (roadmap)
- Hook with specific detail or surprising insight

**Good opening:**
> "At 3:17 AM on a Tuesday, my risk model failed. The system attempted to add 40% portfolio exposure during a flash crash, and I woke up to a monitoring alert. This post covers what went wrong, why my safety mechanisms didn't catch it, and the five architecture changes I made to prevent similar failures."

**Bad opening:**
> "Risk management is one of the most important aspects of systematic trading. Many traders struggle with building robust risk systems, and I've learned a lot over the years. In this post, I want to share some thoughts on risk management and what I've discovered through my journey."

**Body structure:**
- Use headers to chunk content (H2, H3)
- Lead with main point in each section
- Follow with supporting details/examples
- One idea per paragraph
- Use bullets for lists, not long prose

**Technical content:**
- Explain "why" before "how"
- Provide context for decisions
- Include relevant trade-offs
- Show alternatives considered
- Code snippets when helpful (not excessive)

**Closing:**
- Summarize key takeaways (2-4 bullets)
- One clear action or insight to remember
- Optional: what's next (for series) or related topics
- No generic calls to action

### Editing Checklist

**Clarity:**
- [ ] Every paragraph has a clear purpose
- [ ] Technical terms defined or linked on first use
- [ ] No ambiguous pronouns ("it", "this", "that")
- [ ] Transitions between sections clear
- [ ] Examples illustrate rather than confuse

**Conciseness:**
- [ ] Remove filler words ("very", "really", "just")
- [ ] Eliminate redundant explanations
- [ ] Cut unnecessary background/preamble
- [ ] Delete obvious statements
- [ ] Combine similar points

**Technical accuracy:**
- [ ] Code examples tested/verified
- [ ] Numbers and metrics accurate
- [ ] Proper terminology used consistently
- [ ] Citations for claims/research
- [ ] Trade-offs acknowledged

**Strategic alignment:**
- [ ] Reinforces autonomous trading thesis
- [ ] Shows production reality
- [ ] Differentiates from competitors
- [ ] Provides unique value
- [ ] Avoids generic content

**Readability:**
- [ ] Paragraphs under 5 lines
- [ ] Sentences vary in length
- [ ] Headers break up text
- [ ] Bullets where appropriate
- [ ] Scannable structure

### Common Weaknesses to Fix

**Problem: Generic opening**
- Fix: Start with specific example or surprising claim
- Example: "Most trading systems fail at 2AM. Here's why mine didn't."

**Problem: Missing "why" context**
- Fix: Explain decision rationale before implementation
- Example: "I chose PyTorch over TensorFlow for three reasons: [1] dynamic graphs for debugging, [2] ecosystem fit, [3] hiring flexibility if needed."

**Problem: Vague lessons**
- Fix: Specific, concrete takeaways
- Bad: "Communication is important"
- Good: "Log every production decision—future you will thank present you"

**Problem: Over-hedging**
- Fix: State claims confidently with appropriate caveats
- Bad: "I think maybe this approach could potentially work for some people"
- Good: "This approach worked for my portfolio size. It may not scale beyond $10M."

**Problem: Burying the lede**
- Fix: Key insight in first paragraph, not after 10 paragraphs of setup
- Move interesting specific to the top

**Problem: Too much code**
- Fix: Show representative snippets, link to full implementation
- Focus on architectural decisions, not line-by-line walkthroughs

---

## Content Generation Guidelines

When generating new post ideas or drafts:

1. **Start with theme selection**: Which of the 7 categories? Prioritize based on quarterly plan and content mix targets.

2. **Identify target segment**: Which 1-2 audience segments will find this most valuable?

3. **Find specific angle**: Avoid generic topics. What unique insight, failure, or implementation can you share?

4. **Structure the narrative**:
   - Hook with specific detail
   - Explain context/problem
   - Show your approach/solution
   - Share results/lessons
   - Provide takeaways

5. **Maintain voice**: Direct, technical, honest. Like explaining to a peer over coffee, not presenting to executives.

6. **Include specifics**: Real numbers, actual tool names, concrete decisions, dated failures.

7. **Bridge to thesis**: How does this reinforce "solo + AI competes through infrastructure"?

8. **Check differentiation**: Could someone else write this? If yes, add your unique perspective.

---

## Quick Reference

### When evaluating post ideas:
1. Which theme category (1-7)?
2. Score: Strategic Fit + Technical Credibility + Reader Value
3. Target audience segment?
4. Reinforces autonomous trading thesis?
5. Provides unique value?

### When editing drafts:
1. Opening: Specific and hooks immediately?
2. Structure: Clear sections with purpose?
3. Voice: Direct and technical, not fluffy?
4. Examples: Concrete and illustrative?
5. Takeaways: Clear and memorable?

### When planning content:
1. Check quarterly theme balance
2. Alternate technical/human posts
3. Series vs. standalone decision
4. Target segment identified
5. Fits biweekly cadence

### When analyzing audience:
1. Which segment(s) is this for?
2. What do they want to learn?
3. How does this provide unique value?
4. Will this filter right vs. wrong readers?
