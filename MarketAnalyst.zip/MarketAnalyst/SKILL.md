---
name: market-expansion-analyst
description: Comprehensive market expansion analysis framework for Fortune 500 companies evaluating new sector opportunities. Use when analyzing potential market entry, sector expansion feasibility, competitive positioning, regulatory landscape, financial projections, or strategic recommendations for entering new industries or market segments. Triggers include requests for market analysis, sector assessment, expansion strategy, competitive intelligence, TAM/SAM/SOM analysis, or go-to-market planning.
---

# Market Expansion Analyst

Execute comprehensive market expansion analysis for Fortune 500 companies evaluating entry into new sectors.

## Core Analysis Framework

Follow this sequential framework for sector expansion analysis:

### 1. Market Landscape Assessment

**Market Sizing**
- Calculate TAM (Total Addressable Market), SAM (Serviceable Addressable Market), and SOM (Serviceable Obtainable Market)
- Project 5-year CAGR with conservative, baseline, and optimistic scenarios
- Identify market inflection points and growth drivers
- Segment market by geography, customer type, and product category

**Competitive Intelligence**
- Map competitive landscape: incumbents, emerging players, adjacent competitors
- Analyze market share distribution and concentration (HHI index)
- Evaluate competitive moats: brand, network effects, switching costs, economies of scale
- Identify white space opportunities and underserved segments
- Benchmark key performance metrics against top 3-5 players

**Industry Structure**
- Apply Porter's Five Forces: supplier power, buyer power, threat of substitutes, barriers to entry, competitive rivalry
- Map value chain: upstream suppliers to downstream distribution
- Identify key industry partners, intermediaries, and gatekeepers
- Assess vertical integration opportunities

### 2. Regulatory & Compliance Analysis

**Regulatory Framework**
- Identify governing bodies and key regulations
- Map compliance requirements: licensing, certifications, reporting obligations
- Estimate compliance costs (setup + ongoing)
- Flag regulatory risks or pending legislation
- Assess regulatory barriers to entry

**Industry Standards**
- Identify mandatory technical standards and certifications
- Note voluntary industry standards that affect competitiveness
- Evaluate intellectual property landscape and patent risks

### 3. Financial Modeling

**Investment Requirements**
- Capital expenditure: facilities, equipment, technology infrastructure
- Working capital needs: inventory, receivables, payables
- Human capital: headcount plan, compensation benchmarks, training costs
- Marketing and customer acquisition costs

**Revenue Projections**
- Build bottoms-up revenue model: pricing × volume across segments
- Model customer acquisition funnel: awareness → consideration → purchase → retention
- Project customer lifetime value (LTV) by segment
- Establish key assumptions and sensitivity analysis

**Profitability Timeline**
- Create 5-year P&L projection
- Calculate unit economics: contribution margin, CAC payback period, LTV/CAC ratio
- Project break-even timeline
- Model cash flow and funding requirements

**ROI Analysis**
- Calculate NPV, IRR, and payback period
- Compare to hurdle rate and alternative investment opportunities
- Quantify strategic value beyond financial returns

### 4. Risk Assessment

**Market Risks**
- Demand uncertainty and adoption rate assumptions
- Technology disruption and obsolescence risk
- Macroeconomic sensitivity (interest rates, GDP growth, consumer spending)
- Competitive response scenarios

**Operational Risks**
- Supply chain dependencies and concentration
- Talent acquisition and retention challenges
- Technology and infrastructure scalability
- Quality and safety concerns

**Strategic Risks**
- Brand fit and reputation considerations
- Organizational capability gaps
- Distraction from core business
- Strategic commitment and optionality

**Mitigation Strategies**
- Develop risk mitigation plan for top 5-7 risks
- Establish KPIs for early warning signals
- Design staged investment approach with decision gates

### 5. Entry Strategy Recommendations

**Mode of Entry**
- Evaluate: organic growth, acquisition, joint venture, strategic partnership
- Analyze build vs. buy tradeoffs
- Recommend optimal approach with rationale

**Go-to-Market Strategy**
- Define target customer segments (priority order)
- Specify value proposition and positioning
- Outline distribution and channel strategy
- Detail sales model: direct, channel partners, hybrid
- Plan customer acquisition approach and marketing mix

**Operational Blueprint**
- Specify required capabilities: technology, operations, supply chain, talent
- Identify build vs. partner decisions
- Create 18-24 month implementation roadmap with milestones
- Define organizational structure and key hires

**Success Metrics**
- Establish Year 1-3 KPIs: market share, revenue, customer acquisition, profitability
- Define decision criteria for continue/pivot/exit
- Set milestone-based investment gates

## Research Methodology

**Primary Data Sources**
- Industry reports: Gartner, Forrester, IDC, McKinsey, Bain, BCG
- Financial data: company filings (10-K, 10-Q), investor presentations
- Market research: IBISWorld, Euromonitor, Statista
- Trade associations and industry publications
- Expert interviews and primary research when available

**Analysis Tools**
- Use web_search for current market conditions, recent news, and emerging trends
- Use web_fetch for detailed analysis of specific reports, filings, and research
- Cross-reference multiple sources for validation
- Flag data gaps and assumptions explicitly

**Quality Standards**
- Cite all quantitative claims with sources
- Distinguish between facts, estimates, and assumptions
- Present ranges rather than single-point estimates where appropriate
- Acknowledge limitations in available data

## Output Format

Structure analysis as executive-ready deliverable:

1. **Executive Summary** (1-2 pages)
   - Bottom-line recommendation: enter/don't enter, preferred mode
   - Key opportunity highlights (market size, growth, strategic fit)
   - Critical risks and mitigation approaches
   - Required investment and expected returns
   - Implementation timeline

2. **Market Opportunity** (3-5 pages)
   - Market sizing and growth projections with supporting data
   - Competitive landscape analysis with visual mapping
   - White space opportunities

3. **Strategic Fit Assessment** (1-2 pages)
   - Alignment with corporate strategy and capabilities
   - Synergies with existing business units
   - Brand and portfolio considerations

4. **Financial Analysis** (2-3 pages)
   - Investment requirements breakdown
   - Revenue and profitability projections
   - ROI metrics and sensitivity analysis
   - Comparison to alternative investments

5. **Risk Assessment** (2-3 pages)
   - Key risks categorized and prioritized
   - Mitigation strategies
   - Contingency plans

6. **Entry Strategy & Implementation** (3-4 pages)
   - Recommended entry mode with rationale
   - Go-to-market strategy
   - Operational blueprint and org design
   - 18-24 month roadmap with milestones

7. **Appendix**
   - Detailed financial models
   - Methodology and data sources
   - Market research supporting data

## Reference Materials

- **frameworks.md**: Detailed analytical frameworks (Porter's Five Forces, PESTEL, Value Chain Analysis)
- **financial-templates.md**: Financial modeling templates and formulas
- **data-sources.md**: Authoritative data sources by industry sector
- **case-examples.md**: Historical examples of successful and failed market entries

Use these references when deeper guidance is needed on specific analytical approaches.
