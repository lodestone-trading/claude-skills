---
name: equity-analysis
description: "Comprehensive equities financial analysis using 10-Q quarterly reports, macroeconomic and sector analysis, and latest news. Use when Claude needs to: (1) Analyze public company financials, (2) Create investment reports or equity research, (3) Evaluate company performance trends, (4) Assess valuation and investment merit, or (5) Compare companies within a sector"
license: MIT
---

# Equities Financial Analysis Skill

## Overview

This skill provides systematic equity analysis combining:
- 8 most recent 10-Q quarterly earnings reports
- Macroeconomic and sector-specific context
- Latest news and market developments
- Comprehensive financial statement analysis
- Valuation assessment and investment thesis

## When to Use This Skill

Use this skill when analyzing publicly traded companies for:
- Investment research and recommendations
- Company performance evaluation
- Competitive analysis within sectors
- Due diligence for portfolio decisions
- Understanding financial trends and drivers

## Analysis Framework

### Phase 1: Data Collection

#### 10-Q Reports Collection
```python
# SEC EDGAR filing retrieval
import requests
from bs4 import BeautifulSoup

def get_10q_filings(ticker, count=8):
    """Retrieve most recent 10-Q filings from SEC EDGAR"""
    cik = get_cik(ticker)
    url = f"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK={cik}&type=10-Q&count={count}"
    # Parse and download filings
```

**Key sections to extract:**
- Consolidated Balance Sheet
- Consolidated Income Statement
- Consolidated Cash Flow Statement
- Management's Discussion and Analysis (MD&A)
- Risk Factors (material changes)
- Notes to Financial Statements (segment data, debt structure)

#### Macro & Sector Data Sources
**Macroeconomic:**
- Federal Reserve Economic Data (FRED)
- Bureau of Economic Analysis (GDP, inflation)
- Treasury yield curves
- Federal Reserve policy statements

**Sector-Specific:**
- Industry growth rates and forecasts
- Regulatory developments
- Competitive landscape changes
- Technology adoption trends

**Peer Comparison:**
- 3-5 direct competitors
- Same metrics for benchmarking

#### News Collection
```python
# Use web_search and web_fetch tools
# Recent earnings calls transcripts
# Analyst reports and rating changes
# Company announcements (8-Ks)
# Industry news
```

### Phase 2: Financial Statement Analysis

#### Revenue Analysis Workflow
```python
import pandas as pd

# Build 8-quarter revenue dataframe
quarters = ['Q1 2023', 'Q2 2023', ..., 'Q4 2024']
revenue_data = {
    'Quarter': quarters,
    'Revenue': [...],
    'YoY Growth': [...],
    'QoQ Growth': [...]
}
df_revenue = pd.DataFrame(revenue_data)

# Segment breakdown
segments = ['Segment A', 'Segment B', 'Segment C']
# Track each segment's contribution and growth
```

**Key Metrics to Calculate:**
- YoY and QoQ growth rates
- Revenue by segment/geography (% of total)
- Average selling price trends (if applicable)
- Unit volume trends (if applicable)
- Customer concentration metrics

#### Profitability Metrics
Calculate for all 8 quarters:
```python
metrics = {
    'Gross Margin': (gross_profit / revenue) * 100,
    'Operating Margin': (operating_income / revenue) * 100,
    'EBITDA Margin': (ebitda / revenue) * 100,
    'Net Margin': (net_income / revenue) * 100,
    'ROE': (net_income / avg_equity) * 100,
    'ROA': (net_income / avg_assets) * 100,
    'ROIC': (nopat / invested_capital) * 100
}
```

**Margin Trend Analysis:**
- Identify expansion or compression
- Analyze cost structure changes (COGS, SG&A, R&D)
- Assess operating leverage
- Note one-time items impact

#### Balance Sheet Health Assessment
```python
# Liquidity ratios
current_ratio = current_assets / current_liabilities
quick_ratio = (current_assets - inventory) / current_liabilities

# Leverage ratios
debt_to_equity = total_debt / total_equity
interest_coverage = ebit / interest_expense
net_debt_to_ebitda = (total_debt - cash) / ebitda

# Efficiency metrics
inventory_turnover = cogs / avg_inventory
days_sales_outstanding = (accounts_receivable / revenue) * 90
asset_turnover = revenue / avg_total_assets
```

**Quality Checks:**
- Working capital trends
- Goodwill as % of assets (acquisition risk)
- Off-balance sheet liabilities
- Pension obligations

#### Cash Flow Analysis
```python
# Operating Cash Flow quality
ocf_margin = operating_cash_flow / revenue
cash_conversion = operating_cash_flow / net_income

# Free Cash Flow calculation
fcf = operating_cash_flow - capex
fcf_margin = fcf / revenue
fcf_conversion = fcf / net_income

# Capital allocation breakdown
capex_pct = capex / revenue
dividends_paid = total_dividends
share_repurchases = buyback_spending
debt_paydown = debt_reduction
```

### Phase 3: Valuation Analysis

#### Valuation Multiples Over 8 Quarters
```python
# Calculate for each quarter
valuation_metrics = {
    'P/E': market_cap / net_income,
    'Forward P/E': market_cap / forward_earnings,
    'EV/EBITDA': enterprise_value / ebitda,
    'P/S': market_cap / revenue,
    'P/B': market_cap / book_value,
    'PEG': pe_ratio / earnings_growth_rate,
    'Dividend Yield': (annual_dividend / price) * 100
}
```

#### Peer Comparison Framework
```python
peer_comparison = {
    'Company': [ticker] + peer_tickers,
    'Market Cap': [...],
    'P/E': [...],
    'EV/EBITDA': [...],
    'Revenue Growth': [...],
    'EBITDA Margin': [...],
    'ROE': [...]
}
df_peers = pd.DataFrame(peer_comparison)
```

#### DCF Model Considerations
Key inputs to document:
- Revenue CAGR assumptions (3-5 years)
- Terminal growth rate (GDP + inflation)
- WACC calculation components
- FCF margin trajectory

### Phase 4: Qualitative Analysis

#### Management Quality Assessment
- Guidance accuracy (compare prior guidance to actuals)
- Capital allocation track record
- Strategic execution consistency
- Insider transaction patterns

#### Competitive Position Analysis
- Market share trends (3+ years)
- Competitive advantages (moat strength):
  - Network effects
  - Switching costs
  - Brand value
  - Cost advantages
  - Regulatory barriers
- Pricing power evidence

#### Growth Drivers Evaluation
- TAM size and expansion potential
- Product pipeline strength
- Geographic expansion opportunities
- M&A strategy and execution
- Technology advantages

#### Risk Factor Matrix
Create risk assessment table:

| Risk Category | Specific Risk | Likelihood | Impact | Mitigation |
|--------------|---------------|------------|--------|------------|
| Operational | Supply chain | Medium | High | Diversification |
| Financial | Leverage | Low | Medium | FCF generation |
| Competitive | New entrant | Medium | Medium | Moat strength |
| Regulatory | Policy change | Low | High | Compliance |

### Phase 5: Macro & Sector Context

#### Macroeconomic Impact Assessment
```python
# Rate sensitivity analysis
if sector in ['Real Estate', 'Utilities', 'REITs']:
    rate_sensitivity = 'High'
elif sector in ['Technology', 'Consumer Discretionary']:
    rate_sensitivity = 'Medium'
else:
    rate_sensitivity = 'Low'

# Economic cycle positioning
if sector in ['Consumer Staples', 'Healthcare', 'Utilities']:
    cyclicality = 'Defensive'
elif sector in ['Industrials', 'Materials', 'Energy']:
    cyclicality = 'Highly Cyclical'
else:
    cyclicality = 'Cyclical'
```

**Key Macro Factors:**
- Interest rate environment impact
- Inflation effects (cost pass-through ability)
- Currency exposure and hedging
- Credit market conditions
- Labor market dynamics

#### Sector Analysis Framework
- Industry growth rate vs GDP
- Consolidation trends
- Regulatory environment
- Technology disruption risk
- ESG considerations and requirements
- Supply/demand dynamics

#### Market Sentiment Indicators
```python
sentiment_metrics = {
    'Analyst Consensus': 'Buy/Hold/Sell distribution',
    'Price Target Range': 'High/Low/Mean',
    'Estimate Revisions': 'Upgrades vs downgrades',
    'Short Interest': '% of float',
    'Institutional Ownership': '% ownership',
    'Put/Call Ratio': 'Options sentiment'
}
```

### Phase 6: News & Events Analysis

#### Recent Developments Checklist
- Earnings surprises (beat/miss magnitude)
- Product launches or recalls
- Management changes
- Strategic partnerships or terminations
- Restructuring announcements
- Legal/regulatory developments
- M&A activity (buyer or target)

#### Forward-Looking Indicators
- Management guidance changes
- Order book/backlog trends
- Commentary on demand environment
- CapEx plans (expansion vs maintenance)
- R&D investment priorities
- Geographic expansion plans

## Output Format

### Executive Summary
**[Company Name] ([Ticker])**
**Sector:** [Sector Name]
**Current Price:** $XX.XX | **Market Cap:** $XXB | **Date:** [Analysis Date]

**Investment Thesis:** 
[2-3 sentences summarizing the core investment case]

**Key Catalysts:**
- [Catalyst 1]
- [Catalyst 2]
- [Catalyst 3]

**Primary Risks:**
- [Risk 1]
- [Risk 2]
- [Risk 3]

**Recommendation:** [Bullish/Neutral/Bearish]

---

### Financial Performance Analysis

#### Revenue Trends
[8-quarter table with revenue, YoY growth, segment breakdown]

**Key Observations:**
- Revenue growth trajectory and drivers
- Segment performance highlights
- Comparison to guidance

#### Profitability Analysis
[8-quarter table with gross margin, operating margin, EBITDA margin, net margin]

**Key Observations:**
- Margin expansion/compression trends
- Cost structure changes
- Operating leverage evidence
- Peer comparison

#### Balance Sheet & Liquidity
**Current Quarter Metrics:**
- Current Ratio: X.Xx
- Quick Ratio: X.Xx
- Debt/Equity: X.Xx
- Interest Coverage: X.Xx
- Net Debt/EBITDA: X.Xx

**Assessment:** [Strong/Adequate/Concerning]

#### Cash Flow Quality
[8-quarter table with OCF, FCF, CapEx, margins]

**Key Observations:**
- Cash generation consistency
- FCF conversion quality
- Capital allocation priorities
- Sustainability assessment

---

### Valuation Assessment

#### Current Valuation Metrics
| Metric | Current | Avg (8Q) | Sector Median | Premium/Discount |
|--------|---------|----------|---------------|------------------|
| P/E | XX.Xx | XX.Xx | XX.Xx | +/-XX% |
| EV/EBITDA | XX.Xx | XX.Xx | XX.Xx | +/-XX% |
| P/S | XX.Xx | XX.Xx | XX.Xx | +/-XX% |
| P/B | XX.Xx | XX.Xx | XX.Xx | +/-XX% |

#### Peer Comparison
[Comparative valuation table with 3-5 peers]

#### Valuation Summary
**Historical Context:** [Trading at premium/discount to historical average]
**Peer Context:** [Trading at premium/discount to peers because...]
**Fair Value Estimate:** $XX.XX - $YY.YY
**Methodology:** [Multiples-based, DCF considerations, precedent transactions]

---

### Investment Considerations

#### Strengths
1. **[Strength 1 Title]**
   - Supporting data and evidence
   
2. **[Strength 2 Title]**
   - Supporting data and evidence

3. **[Strength 3 Title]**
   - Supporting data and evidence

#### Weaknesses
1. **[Weakness 1 Title]**
   - Supporting data and evidence
   
2. **[Weakness 2 Title]**
   - Supporting data and evidence

3. **[Weakness 3 Title]**
   - Supporting data and evidence

#### Catalysts

**Near-Term (0-6 months):**
- [Catalyst 1 with timing]
- [Catalyst 2 with timing]

**Medium-Term (6-18 months):**
- [Catalyst 1 with timing]
- [Catalyst 2 with timing]

#### Risk Factors

**Company-Specific Risks:**
- [Risk 1]: [Impact assessment]
- [Risk 2]: [Impact assessment]

**Macro/Sector Risks:**
- [Risk 1]: [Impact assessment]
- [Risk 2]: [Impact assessment]

**Probability-Weighted Risk Assessment:** [High/Medium/Low overall risk]

---

### Macro & Sector Context

#### Macroeconomic Environment
[How current macro conditions (rates, inflation, growth) affect the company]

#### Sector Dynamics
[Industry trends, competitive intensity, regulatory environment]

#### Competitive Positioning
[Market share, moat strength, differentiation]

**Sector Outlook:** [Favorable/Neutral/Unfavorable]

---

### Conclusion

**Overall Assessment:** [Bullish/Neutral/Bearish]

**Investment Rationale:**
[Synthesize the analysis into clear investment reasoning]

**Price Target:** $XX.XX - $YY.YY
**Timeframe:** [12-month/18-month]
**Risk/Reward:** [Favorable/Balanced/Unfavorable]

**Monitoring Plan:**
- Key metrics to track: [List]
- Events to watch: [List]
- Thesis invalidation triggers: [List]

---

## Best Practices

### Data Quality
- Always use official SEC filings from EDGAR
- Cross-verify news from multiple credible sources
- Use authoritative sources for macro data (FRED, BEA, BLS)
- Document all data sources with dates and URLs

### Objectivity
- Present both bull and bear arguments
- Quantify all claims with specific metrics
- State assumptions explicitly
- Acknowledge uncertainty and data limitations
- Avoid confirmation bias

### Clarity
- Use consistent formatting throughout
- Create comparison tables for trend analysis
- Define technical terms on first use
- Use visualizations for complex data
- Highlight key insights clearly

### Thoroughness
- Analyze full 8 quarters of data (don't cherry-pick)
- Include segment-level detail where material
- Consider all material risks from 10-Qs
- Compare to peers on same metrics
- Integrate macro and sector context

## Common Pitfalls to Avoid

1. **Single Quarter Focus**
   - Always analyze trends across 8 quarters
   - Don't overweight most recent quarter

2. **Ignoring One-Time Items**
   - Adjust for restructuring charges, asset sales, tax benefits
   - Calculate normalized earnings

3. **Missing Guidance Context**
   - Always compare results to prior guidance
   - Track guidance accuracy over time

4. **Working Capital Neglect**
   - Changes in working capital significantly affect cash flow
   - Analyze inventory, receivables, payables trends

5. **Dilution Oversight**
   - Account for share count changes (buybacks, issuances, options)
   - Use diluted share count for per-share metrics

6. **Cherry-Picking Metrics**
   - Use comprehensive metric set
   - Don't ignore unfavorable metrics

7. **Stale News**
   - Verify news is recent and material
   - Use latest earnings call for management perspective

8. **Sector Ignorance**
   - Always contextualize within sector dynamics
   - Use sector-appropriate metrics (ARPU for telecom, SSS for retail)

## Code Templates

### SEC Filing Retrieval
```python
import requests
import pandas as pd
from bs4 import BeautifulSoup

def get_company_cik(ticker):
    """Get CIK number for company"""
    url = f"https://www.sec.gov/cgi-bin/browse-edgar?company={ticker}&action=getcompany"
    response = requests.get(url, headers={'User-Agent': 'your-email@example.com'})
    soup = BeautifulSoup(response.content, 'html.parser')
    cik = soup.find('span', {'class': 'companyName'})
    return cik.text.split()[0] if cik else None

def get_10q_links(cik, count=8):
    """Get most recent 10-Q filing links"""
    url = f"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK={cik}&type=10-Q&count={count}"
    response = requests.get(url, headers={'User-Agent': 'your-email@example.com'})
    # Parse and return filing URLs
```

### Financial Metrics Calculation
```python
def calculate_margins(revenue, gross_profit, operating_income, net_income, ebitda):
    """Calculate profitability margins"""
    return {
        'gross_margin': (gross_profit / revenue) * 100,
        'operating_margin': (operating_income / revenue) * 100,
        'ebitda_margin': (ebitda / revenue) * 100,
        'net_margin': (net_income / revenue) * 100
    }

def calculate_liquidity(current_assets, current_liabilities, inventory):
    """Calculate liquidity ratios"""
    return {
        'current_ratio': current_assets / current_liabilities,
        'quick_ratio': (current_assets - inventory) / current_liabilities
    }

def calculate_leverage(total_debt, total_equity, ebit, interest_expense, ebitda, cash):
    """Calculate leverage ratios"""
    return {
        'debt_to_equity': total_debt / total_equity,
        'interest_coverage': ebit / interest_expense,
        'net_debt_to_ebitda': (total_debt - cash) / ebitda
    }
```

### Trend Analysis
```python
def analyze_growth_trend(data_series):
    """Analyze growth trend and calculate rates"""
    yoy_growth = [(data_series[i] / data_series[i-4] - 1) * 100 
                  for i in range(4, len(data_series))]
    qoq_growth = [(data_series[i] / data_series[i-1] - 1) * 100 
                  for i in range(1, len(data_series))]
    
    return {
        'latest_yoy': yoy_growth[-1],
        'avg_yoy': sum(yoy_growth) / len(yoy_growth),
        'latest_qoq': qoq_growth[-1],
        'trend': 'accelerating' if yoy_growth[-1] > yoy_growth[-2] else 'decelerating'
    }
```

## Workflow Example

```python
# 1. Collect data
ticker = "AAPL"
cik = get_company_cik(ticker)
filings = get_10q_links(cik, count=8)

# 2. Extract financial data
for filing in filings:
    data = extract_financial_statements(filing)
    # Store in dataframe

# 3. Calculate metrics
df_metrics = calculate_all_metrics(df_financials)

# 4. Get macro and sector data
macro_data = get_macro_indicators()
sector_data = get_sector_metrics(sector="Technology")

# 5. Get latest news
news = web_search(f"{ticker} earnings news analysis")

# 6. Perform analysis
revenue_analysis = analyze_revenue_trends(df_metrics)
profitability_analysis = analyze_margins(df_metrics)
valuation_analysis = compare_valuation_multiples(df_metrics, df_peers)

# 7. Generate report
report = create_equity_report(
    ticker=ticker,
    financial_analysis=financial_analysis,
    valuation_analysis=valuation_analysis,
    qualitative_analysis=qualitative_analysis,
    macro_context=macro_data,
    sector_context=sector_data,
    news_summary=news
)
```

## Tools Integration

### Required Python Libraries
```bash
pip install pandas numpy requests beautifulsoup4 openpyxl
```

### Web Tools to Use
- `web_search`: For recent news, analyst reports, industry trends
- `web_fetch`: For retrieving full articles, SEC filings, company IR pages

### Data Sources
**SEC EDGAR:** https://www.sec.gov/edgar/searchedgar/companysearch
**FRED (Macro Data):** https://fred.stlouisfed.org/
**Company Investor Relations:** [Company website]/investors

## Updates & Maintenance

- Refresh analysis with each new quarterly filing (within 1 week of release)
- Update macro/sector view quarterly or when material changes occur
- Monitor news continuously for thesis-changing developments
- Reassess valuation when stock moves >10% or multiples diverge significantly
- Update peer comparison semi-annually or when competitive dynamics shift

## Final Checklist

Before finalizing analysis, verify:
- [ ] All 8 quarters of data collected and analyzed
- [ ] Key metrics calculated correctly (formulas verified)
- [ ] Peer comparison uses same metrics and time periods
- [ ] All claims supported by specific data points
- [ ] One-time items identified and adjusted
- [ ] Management guidance incorporated
- [ ] Macro and sector context integrated
- [ ] Both bullish and bearish cases presented
- [ ] Risk factors from 10-Qs included
- [ ] News is current (within 30 days)
- [ ] Sources documented with dates
- [ ] No formula errors in calculations
- [ ] Valuation methodology clearly stated
- [ ] Investment thesis is clear and actionable
