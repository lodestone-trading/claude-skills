# Tax Elections Reference

## Section 475 Mark-to-Market Election

### Overview
Converts trading gains/losses to ordinary income, eliminating wash sale tracking and $3k capital loss limitations.

### Eligibility (TTS Qualification)
1. Substantial, regular trading activity
2. Seeks profit from daily price movements (not dividends/long-term appreciation)
3. Substantial time devoted to trading

### Election Procedure

**New Entity (first tax year)**:
- Attach election statement to first tax return
- File Form 3115 (Change in Accounting Method)

**Existing Entity**:
- Must elect by April 15 of the tax year to take effect
- Attach statement to prior year return
- File Form 3115 with current year return

**Election Statement Template**:
```
Pursuant to IRC Section 475(f)(1), [Entity Name] hereby elects 
to use the mark-to-market method of accounting for securities. 
This election is effective for taxable year beginning [Date].
```

### Revocation
- Requires IRS private letter ruling
- Generally locked in for 5 years

## S-Corp Election (Form 2553)

### Timing
| Scenario | Deadline |
|----------|----------|
| New LLC | 75 days from formation or tax year start |
| Existing LLC (current year) | March 15 |
| Existing LLC (next year) | By end of current tax year |

### Requirements
- ≤100 shareholders, one stock class
- All shareholders must sign consent
- No nonresident alien shareholders

### Late Election Relief
- Show reasonable cause
- Write "FILED PURSUANT TO REV. PROC. 2013-30" at top of Form 2553

## Retirement Plan Deadlines

| Plan | Establish By | Contribute By |
|------|-------------|---------------|
| Solo 401(k) | Dec 31 | Tax deadline + ext |
| SEP-IRA | Tax deadline + ext | Tax deadline + ext |
| Traditional IRA | Tax deadline | Tax deadline |

## Estimated Tax (Form 1040-ES)

| Quarter | Period | Due |
|---------|--------|-----|
| Q1 | Jan-Mar | Apr 15 |
| Q2 | Apr-May | Jun 15 |
| Q3 | Jun-Aug | Sep 15 |
| Q4 | Sep-Dec | Jan 15 |

### Safe Harbors
- 90% current year tax
- 100% prior year tax (110% if AGI > $150k)
