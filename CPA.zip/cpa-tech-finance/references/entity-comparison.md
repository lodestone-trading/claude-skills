# Entity Structure Comparison

## Overview Matrix

| Factor | Sole Prop / SMLLC | S-Corp | Partnership/Multi-Member LLC |
|--------|-------------------|--------|------------------------------|
| Formation | Simple, low cost | Requires election | Operating agreement needed |
| Tax Filing | Schedule C | Form 1120-S + K-1 | Form 1065 + K-1s |
| SE Tax | All net income | W-2 wages only | Varies by partner |
| Losses | Deduct on personal | Pass-through | Pass-through |
| Admin Burden | Minimal | Payroll, corp formalities | K-1 prep, operating agreement |
| State Fees | Low | Varies (some have min franchise tax) | Varies |

## When to Choose Each Structure

### Stay as SMLLC When
- Net income under ~$60k (SE tax savings don't offset admin costs)
- Expecting significant losses to offset other income
- Simplicity is priority
- Testing new trading strategy

### Elect S-Corp When
- Net income consistently above ~$80k
- Can justify reasonable salary at 40-60% of net
- Willing to run payroll (quarterly 941s, annual W-2/W-3)
- State doesn't have punitive S-Corp taxes

### Partnership/Multi-Member When
- Multiple owners
- Want flexibility in profit/loss allocations
- Different capital contribution levels
- Planning for future equity partners

## S-Corp SE Tax Savings Example

**Scenario**: $200k net trading income

| Structure | SE Tax Calculation |
|-----------|-------------------|
| SMLLC | $200k × 15.3% × 92.35% = ~$28,259 |
| S-Corp (80k salary) | $80k × 15.3% = $12,240 |
| **Savings** | **~$16,000/year** |

**Offset Costs**:
- Payroll service: $500-1,500/yr
- Additional tax prep: $500-1,000/yr
- Potential state franchise taxes
- Net savings still typically $10k+ at this income level

## Reasonable Salary Guidelines

IRS factors for determining reasonable compensation:
- Training and experience
- Duties and responsibilities
- Time devoted to business
- Comparable salaries for similar work
- Dividend history

**Rule of Thumb**: 40-60% of net profits as salary when total distributions exceed $50k

**Red Flags**:
- Zero salary with large distributions
- Salary significantly below industry norms
- Salary that varies wildly with profits

## Payroll Requirements for S-Corp

### Quarterly
- Form 941 (federal employment taxes)
- State withholding deposit
- State unemployment

### Annual
- W-2/W-3 to SSA (due Jan 31)
- Form 940 (FUTA)
- State annual reconciliation

### Options
- DIY with Gusto, Paychex, etc. ($40-100/mo)
- CPA-managed payroll (included in service fee)

## State-Specific Considerations

### States with S-Corp Minimum Taxes/Fees
- California: $800 franchise tax minimum
- New York: Graduated tax based on income
- Delaware: $300 franchise tax (but no state income tax)

### States Favorable to S-Corps
- Texas (no state income tax)
- Florida (no state income tax)
- Wyoming (no state income tax, low fees)

## Conversion Considerations

### LLC → S-Corp
- File Form 2553 (timing critical)
- Set up payroll
- Adjust bookkeeping for owner distributions vs salary
- No immediate tax consequences if done properly

### S-Corp → LLC
- May trigger deemed liquidation
- Consult CPA before revoking S election
- Consider waiting out 5-year restriction period
