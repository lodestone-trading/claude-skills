# Deduction Documentation Checklist

## Home Office (Form 8829)

### Regular Method
**Required Documentation**:
- [ ] Floor plan with office measurements
- [ ] Total home square footage
- [ ] Mortgage interest / rent statements
- [ ] Property tax statements
- [ ] Homeowners/renters insurance
- [ ] Utilities (electric, gas, water, internet)
- [ ] Repairs and maintenance records
- [ ] Photos showing exclusive business use

**Calculation**: (Office sq ft / Total sq ft) × Eligible expenses

### Simplified Method
- $5 per sq ft, max 300 sq ft ($1,500 max)
- No depreciation recapture on sale
- Less documentation required

## Equipment & Technology

### Section 179 Immediate Expensing
**2024 Limits**: $1,160,000 deduction, $2,890,000 phase-out threshold

**Qualifying Property**:
- [ ] Computers and monitors
- [ ] Servers and networking equipment
- [ ] Office furniture
- [ ] Trading-specific hardware

**Required Documentation**:
- [ ] Purchase receipts with date, amount, description
- [ ] Business purpose statement
- [ ] Photo of equipment in use
- [ ] Serial numbers for high-value items

### MACRS Depreciation (Alternative)
| Asset Class | Recovery Period |
|-------------|-----------------|
| Computers | 5 years |
| Office furniture | 7 years |
| Qualified improvement | 15 years |

## Data & Research Subscriptions

**Common Deductible Expenses**:
- [ ] Market data feeds (Bloomberg, Refinitiv, etc.)
- [ ] Research platforms and APIs
- [ ] News subscriptions (WSJ, FT, etc.)
- [ ] Technical analysis software
- [ ] Backtesting platforms

**Documentation**:
- [ ] Subscription agreements
- [ ] Monthly/annual invoices
- [ ] Payment records
- [ ] Business purpose statement if dual-use

## Software & Platform Fees

**Categories**:
- [ ] Trading platforms
- [ ] IDE and development tools
- [ ] Cloud services (AWS, GCP, Azure)
- [ ] Monitoring and observability
- [ ] Security tools
- [ ] Collaboration software

**Documentation**:
- [ ] Invoices/receipts
- [ ] Service agreements
- [ ] Allocation methodology if personal use exists

## Professional Services

**Deductible Categories**:
- [ ] Accounting and tax preparation
- [ ] Legal (entity formation, contracts)
- [ ] Consulting fees
- [ ] Advisory services

**Documentation**:
- [ ] Engagement letters
- [ ] Invoices with service description
- [ ] Payment records

## Travel & Transportation

**Business Travel**:
- [ ] Conference/seminar attendance
- [ ] Client/investor meetings
- [ ] Professional development events

**Required Records**:
- [ ] Itinerary with business purpose
- [ ] Receipts for lodging, airfare, ground transport
- [ ] Meals (50% deductible, must document attendees/purpose)
- [ ] Registration fees for conferences

**Vehicle Use** (if applicable):
- [ ] Mileage log (date, destination, purpose, miles)
- [ ] Standard mileage rate: $0.67/mile (2024)
- [ ] OR actual expenses with business use percentage

## Education & Professional Development

**Deductible If**:
- Maintains or improves skills in current business
- Required for maintaining license/certification
- Does NOT qualify you for new trade/business

**Documentation**:
- [ ] Course descriptions
- [ ] Payment receipts
- [ ] Certificates of completion
- [ ] Business purpose statement

## Insurance

**Business Insurance Types**:
- [ ] Professional liability (E&O)
- [ ] Cyber liability
- [ ] Business property
- [ ] Health insurance (self-employed deduction, above-the-line)

**Documentation**:
- [ ] Policy declarations
- [ ] Premium payment records

## Retirement Contributions

### Solo 401(k) (2024)
- Employee deferral: $23,000 ($30,500 if 50+)
- Employer profit sharing: 25% of net self-employment income
- Combined max: $69,000 ($76,500 if 50+)

### SEP-IRA (2024)
- 25% of net self-employment income
- Max: $69,000

**Documentation**:
- [ ] Plan documents
- [ ] Contribution records
- [ ] Adoption agreement (for new plans)

## Record Retention Guidelines

| Document Type | Retention Period |
|--------------|------------------|
| Tax returns | 7 years |
| Income/expense records | 7 years |
| Asset purchase records | Life of asset + 7 years |
| Employment tax records | 4 years |
| Bank statements | 7 years |
| Contracts/agreements | Life + 7 years |

## Dual-Use Allocation

For expenses with both personal and business use:
1. Document total expense
2. Establish reasonable allocation methodology
3. Apply consistently
4. Retain supporting records for allocation basis

**Examples**:
- Internet: Time tracking or fixed percentage
- Phone: Separate lines or usage analysis
- Vehicle: Mileage log
