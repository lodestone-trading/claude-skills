---
name: cpa-tech-finance
description: Certified Public Accountant expertise for technology and finance firms, particularly proprietary trading operations. Use when Claude needs to assist with tax optimization strategies (trader tax status, Section 475 elections, wash sale rules, pass-through entity taxation), bookkeeping best practices (chart of accounts, accrual vs cash basis, reconciliation workflows), financial statement preparation, quarterly estimated tax planning, entity structure optimization (LLC, S-Corp considerations), R&D tax credits for ML/software development, home office and equipment deductions, retirement account strategies for self-employed traders, and general tax compliance for systematic trading firms.
---

# CPA for Technology & Finance Firms

Specialized accounting and tax guidance for proprietary trading firms and technology-focused financial operations.

## Tax Optimization

### Trader Tax Status (TTS)

Qualified traders may elect Section 475 mark-to-market accounting:
- Converts capital gains/losses to ordinary income/losses
- Eliminates wash sale rule restrictions
- Removes $3,000 annual capital loss limitation
- Election deadline: April 15 of the tax year (new traders) or prior year for existing

**TTS Qualification Factors**: Substantial and regular trading activity, seeks profit from daily market movements (not long-term appreciation), trades on substantially full-time basis.

### Entity Structure

| Structure | Tax Treatment | SE Tax | Best For |
|-----------|--------------|--------|----------|
| Sole Prop/SMLLC | Schedule C | Full net income | Simplicity, losses |
| S-Corp | W-2 + K-1 | W-2 wages only | Reducing SE tax when profitable |
| Partnership | K-1 | Varies | Multiple members, flexibility |

**S-Corp Reasonable Salary**: IRS scrutinizes low salaries. Rule of thumb: 40-60% of net as salary when distributions exceed $50k.

### Key Deductions

- **Data/Research**: Market data, Bloomberg, research subscriptions
- **Technology**: Servers, cloud compute, hardware (Section 179 or MACRS)
- **Software**: Trading platforms, IDE licenses, monitoring tools
- **Home Office**: Percentage of rent/mortgage, utilities, insurance (regular & exclusive use required)
- **Professional**: Legal, accounting, consulting fees
- **Education**: Courses, conferences directly related to trading activity

### R&D Tax Credits

Technology firms developing ML/AI systems may qualify:
- Algorithm development and experimentation
- Infrastructure for backtesting and simulation
- New or improved software functionality
- Credit: ~6-8% of qualified research expenditures
- Startup election available against payroll taxes

## Bookkeeping Standards

### Chart of Accounts Structure

```
1000 Assets
  1010 Operating Cash
  1100-1199 Brokerage Accounts (by broker)
  1300 Equipment
  1400 Prepaid Expenses

2000 Liabilities
  2010 Credit Cards
  2100 Accrued Expenses
  2200 Taxes Payable

3000 Equity
  3010 Member Capital
  3020 Retained Earnings
  3030 Distributions

4000 Revenue
  4010 Trading Gains - Short Term
  4020 Trading Gains - Long Term
  4030 Dividend Income
  4040 Interest Income

5000 Expenses
  5100 Data & Research
  5200 Software & Platforms
  5300 Infrastructure & Compute
  5400 Professional Services
  5500 Office & Administrative
```

### Reconciliation Cadence

| Frequency | Tasks |
|-----------|-------|
| Daily | Brokerage P&L verification, position reconciliation |
| Monthly | Bank/CC reconciliation, expense categorization, accruals review |
| Quarterly | Estimated tax calc, interim financials, variance analysis |
| Annual | 1099 reconciliation, K-1 prep, return preparation, elections |

## Estimated Taxes

**Due Dates**: Q1 Apr 15, Q2 Jun 15, Q3 Sep 15, Q4 Jan 15

**Safe Harbors**:
- 100% of prior year tax (110% if AGI > $150k)
- 90% of current year tax

**Annualized Method**: Calculate based on income through each quarter-end; useful for variable income.

## Year-End Planning

- Maximize Solo 401(k) contributions ($23,500 employee + 25% profit sharing, 2024)
- Review Section 199A QBI deduction eligibility (20% of qualified business income)
- Tax-loss harvesting (if not under Section 475)
- Confirm all estimated payments meet safe harbor
- Document home office measurements, equipment purchase dates

## Reference Files

- `references/tax-elections.md`: Section 475 procedures, entity election deadlines
- `references/entity-comparison.md`: Detailed LLC vs S-Corp analysis with examples
- `references/deduction-checklist.md`: Documentation requirements for each deduction category
